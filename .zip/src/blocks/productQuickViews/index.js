export { default as IndexView } from './IndexView';
export { default as PopupBoxWithProductDetails } from './PopupBoxWithProductDetails';
