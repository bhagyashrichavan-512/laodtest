export { default } from './PopupBoxWithProductDetails';
