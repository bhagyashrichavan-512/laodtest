export { default as IndexView } from './IndexView';
export { default as WithTwoColumns } from './WithTwoColumns';
