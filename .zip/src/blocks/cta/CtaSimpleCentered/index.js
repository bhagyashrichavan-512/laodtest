export { default } from './CtaSimpleCentered';
