export { default } from './CtaAlignedLeftWithTypedText';
