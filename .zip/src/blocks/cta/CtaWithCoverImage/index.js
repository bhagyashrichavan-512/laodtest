export { default } from './CtaWithCoverImage';
