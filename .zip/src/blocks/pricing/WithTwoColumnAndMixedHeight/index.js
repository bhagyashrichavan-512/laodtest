export { default } from './WithTwoColumnAndMixedHeight';
