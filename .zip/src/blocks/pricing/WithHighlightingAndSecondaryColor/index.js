export { default } from './WithHighlightingAndSecondaryColor';
