export { default } from './SingleChoiceOption';
