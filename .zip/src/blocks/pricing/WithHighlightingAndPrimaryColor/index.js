export { default } from './WithHighlightingAndPrimaryColor';
