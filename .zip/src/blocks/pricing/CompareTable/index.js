export { default } from './CompareTable';
