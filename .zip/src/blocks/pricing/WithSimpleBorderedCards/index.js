export { default } from './WithSimpleBorderedCards';
