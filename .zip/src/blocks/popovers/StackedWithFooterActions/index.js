export { default } from './StackedWithFooterActions';
