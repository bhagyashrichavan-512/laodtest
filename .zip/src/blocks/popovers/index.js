export { default as IndexView } from './IndexView';
export { default as Simple } from './Simple';
export { default as StackedWithFooterActions } from './StackedWithFooterActions';
export { default as WithRecentPosts } from './WithRecentPosts';
export { default as WithTwoColumnGrid } from './WithTwoColumnGrid';
