export { default } from './WithRecentPosts';
