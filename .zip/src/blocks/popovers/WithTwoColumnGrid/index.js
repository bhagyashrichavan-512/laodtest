export { default } from './WithTwoColumnGrid';
