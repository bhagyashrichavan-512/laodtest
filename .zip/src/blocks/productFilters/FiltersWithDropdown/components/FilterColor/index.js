export { default } from './FilterColor';
