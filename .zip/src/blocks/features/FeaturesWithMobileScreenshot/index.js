export { default } from './FeaturesWithMobileScreenshot';
