export { default } from './FeaturesWithCheckMarksAndAbstractImages';
