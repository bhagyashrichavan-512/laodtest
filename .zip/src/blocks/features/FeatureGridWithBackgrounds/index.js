export { default } from './FeatureGridWithBackgrounds';
