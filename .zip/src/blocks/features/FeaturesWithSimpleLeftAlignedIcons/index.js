export { default } from './FeaturesWithSimpleLeftAlignedIcons';
