export { default } from './FeaturesWithMinimalDesign';
