export { default } from './SimpleFeaturesWithAlternateCards';
