export { default } from './FeaturesWithIllustration';
