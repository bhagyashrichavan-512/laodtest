export { default } from './FeaturesWithSimpleIcons';
