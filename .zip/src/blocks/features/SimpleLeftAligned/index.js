export { default } from './SimpleLeftAligned';
