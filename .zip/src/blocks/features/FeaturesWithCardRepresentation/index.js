export { default } from './FeaturesWithCardRepresentation';
