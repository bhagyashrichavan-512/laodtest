export { default } from './SimpleCentered';
