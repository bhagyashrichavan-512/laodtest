export { default } from './NewsletterWithImage';
