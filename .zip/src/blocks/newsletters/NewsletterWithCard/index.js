export { default } from './NewsletterWithCard';
