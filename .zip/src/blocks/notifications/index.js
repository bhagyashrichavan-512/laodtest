export { default as IndexView } from './IndexView';
export { default as Simple } from './Simple';
export { default as WithActionButtons } from './WithActionButtons';
export { default as WithAvatarAndButtonsBelow } from './WithAvatarAndButtonsBelow';
export { default as WithSplitButtons } from './WithSplitButtons';
