export { default } from './WithFixedSidebar';
