export { default } from './WithNarrowLayoutAndNoSidebar';
