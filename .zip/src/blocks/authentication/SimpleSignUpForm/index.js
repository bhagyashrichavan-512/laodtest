export { default } from './SimpleSignUpForm';
