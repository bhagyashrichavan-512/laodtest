export { default } from './SignUpFormWithCoverImage';
