export { default } from './ResetPasswordSimpleForm';
