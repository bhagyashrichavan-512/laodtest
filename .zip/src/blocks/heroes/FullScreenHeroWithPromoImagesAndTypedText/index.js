export { default } from './FullScreenHeroWithPromoImagesAndTypedText';
