export { default } from './HeroWithPrimaryBackgroundAndDesktopScreenshot';
