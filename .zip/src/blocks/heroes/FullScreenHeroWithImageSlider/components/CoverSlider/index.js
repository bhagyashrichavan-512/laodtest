export { default } from './CoverSlider';
