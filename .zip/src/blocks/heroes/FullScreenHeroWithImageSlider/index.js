export { default } from './FullScreenHeroWithImageSlider';
