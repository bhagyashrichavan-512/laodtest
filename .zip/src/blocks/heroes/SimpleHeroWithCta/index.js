export { default } from './SimpleHeroWithCta';
