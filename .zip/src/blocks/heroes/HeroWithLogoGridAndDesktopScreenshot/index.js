export { default } from './HeroWithLogoGridAndDesktopScreenshot';
