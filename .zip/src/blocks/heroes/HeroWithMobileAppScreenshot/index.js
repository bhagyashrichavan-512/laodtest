export { default } from './HeroWithMobileAppScreenshot';
