export { default } from './HeroForEcommerceApp';
