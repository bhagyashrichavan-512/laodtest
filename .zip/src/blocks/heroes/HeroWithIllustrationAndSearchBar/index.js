export { default } from './HeroWithIllustrationAndSearchBar';
