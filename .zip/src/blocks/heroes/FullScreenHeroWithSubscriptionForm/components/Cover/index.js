export { default } from './Cover';
