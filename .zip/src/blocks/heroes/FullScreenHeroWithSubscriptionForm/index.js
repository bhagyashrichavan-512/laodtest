export { default } from './FullScreenHeroWithSubscriptionForm';
