export { default } from './HeroWithFormAndBackgroundGradient';
