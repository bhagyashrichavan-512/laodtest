export { default } from './SimpleHeroWithBottomVideo';
