export { default } from './SimpleHeroWithImageAndCtaButtons';
