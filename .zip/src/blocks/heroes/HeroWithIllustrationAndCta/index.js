export { default } from './HeroWithIllustrationAndCta';
