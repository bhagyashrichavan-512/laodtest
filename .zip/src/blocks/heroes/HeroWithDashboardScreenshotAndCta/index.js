export { default } from './HeroWithDashboardScreenshotAndCta';
