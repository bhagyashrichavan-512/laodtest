export { default } from './HeroWithBackgroundVideo';
