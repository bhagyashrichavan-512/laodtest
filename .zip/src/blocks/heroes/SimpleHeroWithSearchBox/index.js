export { default } from './SimpleHeroWithSearchBox';
