export { default } from './FullScreenHeroWithLogoGrid';
