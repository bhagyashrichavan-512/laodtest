export { default } from './CardWithColorAccent';
