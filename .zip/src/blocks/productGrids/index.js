export { default as IndexView } from './IndexView';
export { default as WithCtaButton } from './WithCtaButton';
export { default as MinimallyDesigned } from './MinimallyDesigned';
export { default as WithPromoBadge } from './WithPromoBadge';
