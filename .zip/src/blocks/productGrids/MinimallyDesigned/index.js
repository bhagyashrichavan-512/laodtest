export { default } from './MinimallyDesigned';
