export { default } from './WithPromoBadge';
