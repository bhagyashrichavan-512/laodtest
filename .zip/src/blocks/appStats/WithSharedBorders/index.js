export { default } from './WithSharedBorders';
