export { default } from './Simple';
