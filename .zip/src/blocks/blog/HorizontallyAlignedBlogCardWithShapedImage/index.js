export { default } from './HorizontallyAlignedBlogCardWithShapedImage';
