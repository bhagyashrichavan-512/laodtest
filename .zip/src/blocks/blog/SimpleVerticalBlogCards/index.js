export { default } from './SimpleVerticalBlogCards';
