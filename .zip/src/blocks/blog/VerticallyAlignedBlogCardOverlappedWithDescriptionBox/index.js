export { default } from './VerticallyAlignedBlogCardOverlappedWithDescriptionBox';
