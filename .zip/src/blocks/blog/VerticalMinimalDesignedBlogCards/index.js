export { default } from './VerticalMinimalDesignedBlogCards';
