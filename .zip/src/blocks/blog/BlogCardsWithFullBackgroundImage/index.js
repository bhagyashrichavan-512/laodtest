export { default } from './BlogCardsWithFullBackgroundImage';
