export { default } from './VerticallyAlignedBlogCardsWithShapedImage';
