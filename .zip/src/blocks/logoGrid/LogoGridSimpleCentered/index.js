export { default } from './LogoGridSimpleCentered';
