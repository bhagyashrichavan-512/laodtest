export { default } from './WithLeftAlignedDescriptionBoxAndBoxedLogos';
