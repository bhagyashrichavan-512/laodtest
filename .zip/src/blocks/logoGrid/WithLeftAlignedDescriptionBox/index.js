export { default } from './WithLeftAlignedDescriptionBox';
