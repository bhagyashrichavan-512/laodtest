export { default } from './WithDarkBackgroundAndSimpleDescriptionBox';
