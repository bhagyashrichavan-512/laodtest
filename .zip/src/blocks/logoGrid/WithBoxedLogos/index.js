export { default } from './WithBoxedLogos';
