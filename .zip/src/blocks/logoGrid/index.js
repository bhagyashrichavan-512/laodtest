export { default as IndexView } from './IndexView';
export { default as LogoGridSimpleCentered } from './LogoGridSimpleCentered';
export { default as WithBoxedLogos } from './WithBoxedLogos';
export { default as WithLeftAlignedDescriptionBox } from './WithLeftAlignedDescriptionBox';
export { default as WithSwiperAndBrandBackgroundColor } from './WithSwiperAndBrandBackgroundColor';
export { default as WithLeftAlignedDescriptionBoxAndBoxedLogos } from './WithLeftAlignedDescriptionBoxAndBoxedLogos';
export { default as WithDarkBackgroundAndSimpleDescriptionBox } from './WithDarkBackgroundAndSimpleDescriptionBox';
