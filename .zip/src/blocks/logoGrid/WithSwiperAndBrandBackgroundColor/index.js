export { default } from './WithSwiperAndBrandBackgroundColor';
