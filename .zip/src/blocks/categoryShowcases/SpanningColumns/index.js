export { default } from './SpanningColumns';
