export { default } from './WithImageGrid';
