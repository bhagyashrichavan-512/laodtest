export { default } from './ShowcaseBgImage';
