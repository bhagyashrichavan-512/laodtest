export { default as Image } from './Image';
export { default as Details } from './Details';
