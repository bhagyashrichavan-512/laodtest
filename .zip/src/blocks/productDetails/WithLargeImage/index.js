export { default } from './WithLargeImage';
