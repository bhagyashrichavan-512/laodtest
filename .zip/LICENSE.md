# License

You can find more details about the license at https://mui.com/store/license/